"""LMA probes for tutorials/language_model_artifact_inference_colab.ipynb (row 37).

Direct CPU execution of the notebook's own code cells, in order, in one namespace, with:
- the install cell run with DIMER_NOTEBOOK_CI_PREINSTALLED=1 (no pip; local env torch 2.13.0+cpu,
  transformers 4.57.6, peft 0.18.0, accelerate 1.11.0 -- NOT the notebook's pins);
- the pinned SmolLM2-360M snapshot hard-linked from a local copy (no Hub download; verify_snapshot still
  re-hashes every file against the notebook's inline manifest);
- a STAND-IN adapter bundle built here with PEFT + the carried module's export_adapter_bundle (random
  non-zero LoRA B), because no E2E-produced bundle is published. It is not the E2E bundle.
Form fields are changed by rewriting the `# @param` line, as the Colab form does.
Usage: python run_probes.py <notebook.ipynb> <workdir> <local_snapshot_dir>
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB, WORK, SNAP = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
RESULTS: dict = {"notebook": str(NB), "notebook_sha256": hashlib.sha256(NB.read_bytes()).hexdigest(), "probes": {}}
T0 = time.time()


def record(pid, **kw):
    kw["t_s"] = round(time.time() - T0, 1)
    RESULTS["probes"][pid] = kw
    print(pid, json.dumps(kw, ensure_ascii=False, default=str)[:600], flush=True)
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
CELLS = {i: "".join(c["source"]) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"}
RESULTS["code_cells"] = sorted(CELLS)


def with_params(src, **params):
    for name, value in params.items():
        pat = re.compile(rf"^{name} = .*?(  # @param.*)$", re.M)
        assert pat.search(src), f"param {name} not found"
        src = pat.sub(lambda m: f"{name} = {value!r}{m.group(1)}", src)
    return src


def run(ns, idx, **params):
    src = with_params(CELLS[idx], **params) if params else CELLS[idx]
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(src, f"cell{idx}", "exec"), ns)
        err = None
    except BaseException as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
    finally:
        sys.stdout = old
    return err, buf.getvalue()


# ---- workdir + snapshot (hard links; the notebook writes its own manifest file) ----
shutil.rmtree(WORK / "weights", ignore_errors=True)
for d in ("outputs", "work", "bundles"):
    shutil.rmtree(WORK / d, ignore_errors=True)
snapdir = WORK / "weights" / "smollm2-360m"
snapdir.mkdir(parents=True)
for f in SNAP.iterdir():
    if f.is_file() and f.name not in ("dimer-base-manifest.json", "MODEL_CARD.md"):
        os.link(f, snapdir / f.name)
os.chdir(WORK)
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
ns: dict = {"__name__": "__main__"}

# P1 install cell (skip path) -----------------------------------------------------------
err, out = run(ns, 3)
record("P1_install_cell_skip_path", error=err, out=out.strip()[-400:],
       note="pip skipped via DIMER_NOTEBOOK_CI_PREINSTALLED=1; local CPU env, not the notebook's pins")

# P2 module + P3 model cell ---------------------------------------------------------------
err, out = run(ns, 5)
record("P2_module_cell", error=err)
err, out = run(ns, 7)
record("P3_stage_verify_load", error=err, out=out.strip()[-700:])
if err:
    sys.exit(1)
pipe = ns["pipe"]

# ---- stand-in bundles built with the carried module's export path ----
import torch  # noqa: E402
from peft import LoraConfig, get_peft_model  # noqa: E402
from transformers import AutoModelForCausalLM  # noqa: E402


def make_bundle(name, b_scale, provenance_extra=None):
    base = AutoModelForCausalLM.from_pretrained(str(snapdir), local_files_only=True, dtype=torch.float32)
    cfg = LoraConfig(r=8, lora_alpha=16, target_modules=["q_proj", "v_proj"], lora_dropout=0.0, task_type="CAUSAL_LM")
    pm = get_peft_model(base, cfg)
    g = torch.Generator().manual_seed(0)
    with torch.no_grad():
        for n, p in pm.named_parameters():
            if "lora_B" in n:
                p.copy_(torch.randn(p.shape, generator=g) * b_scale)
    out_dir = WORK / "bundles" / name
    prov = {"datasetDigest": "stand-in", "dataset": {"id": "stand-in (review probe)"},
            "training": {"method": "stand-in random LoRA-B, not trained"}, "runtime": {"python": sys.version.split()[0]}}
    prov.update(provenance_extra or {})
    ns["pipe"].export_adapter_bundle(pm, out_dir, metrics={"note": "stand-in"}, provenance=prov)
    zpath = WORK / "bundles" / f"{name}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_STORED) as z:  # same layout as the E2E template
        for path in sorted(out_dir.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(out_dir).as_posix())
    del pm, base
    return out_dir, zpath


good_dir, good_zip = make_bundle("good", 0.05)
tiny_dir, tiny_zip = make_bundle("tiny", 1e-9)
zero_dir, zero_zip = make_bundle("zero", 0.0)
record("P4_standin_bundles", good=str(good_dir), files=sorted(p.name for p in good_dir.iterdir()),
       good_zip_sha256=hashlib.sha256(good_zip.read_bytes()).hexdigest())

# P5 default Run all path outside Colab: ARTIFACT_DIR='' -> upload branch imports google.colab
err, out = run(ns, 9)
record("P5_default_artifact_cell_no_colab", error=err,
       note="Run-all default (ARTIFACT_DIR empty) on a non-Colab Jupyter kernel")

# P6 upload branch via a google.colab shim -------------------------------------------------
shim_pkg = types.ModuleType("google.colab")
files_mod = types.ModuleType("google.colab.files")
UPLOAD = {}
files_mod.upload = lambda: dict(UPLOAD)
shim_pkg.files = files_mod
google_mod = sys.modules.get("google") or types.ModuleType("google")
sys.modules.setdefault("google", google_mod)
sys.modules["google.colab"] = shim_pkg
sys.modules["google.colab.files"] = files_mod
setattr(google_mod, "colab", shim_pkg)

UPLOAD.clear()
err, _ = run(ns, 9)
record("P6a_upload_cancelled", error=err)
UPLOAD.clear(); UPLOAD[good_zip.name] = good_zip.read_bytes()
err, _ = run(ns, 9, EXPECTED_ARTIFACT_ZIP_SHA256="0" * 64)
record("P6b_upload_wrong_expected_sha", error=err)
err, out = run(ns, 9, EXPECTED_ARTIFACT_ZIP_SHA256=hashlib.sha256(good_zip.read_bytes()).hexdigest())
record("P6c_upload_good_with_sha", error=err, out=out.strip()[-500:])

# zip-slip archive
evil = WORK / "bundles" / "evil.zip"
with zipfile.ZipFile(evil, "w") as z:
    z.writestr("../escape.txt", "x")
UPLOAD.clear(); UPLOAD["evil.zip"] = evil.read_bytes()
err, _ = run(ns, 9)
record("P6d_upload_zip_slip", error=err, escaped=(WORK / "work" / "escape.txt").exists())

# P7 ARTIFACT_DIR set + wrong expected sha (silently ignored in directory mode?) -------------
err, out = run(ns, 9, ARTIFACT_DIR=str(good_dir), EXPECTED_ARTIFACT_ZIP_SHA256="0" * 64)
record("P7_dir_mode_ignores_expected_sha", error=err, accepted=err is None,
       note="EXPECTED_ARTIFACT_ZIP_SHA256 set to a wrong value while ARTIFACT_DIR is set")

# P8 tampering controls in directory mode ----------------------------------------------------
def tampered(name, mutate):
    d = WORK / "bundles" / f"t_{name}"
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(good_dir, d)
    mutate(d)
    return run(ns, 9, ARTIFACT_DIR=str(d))[0]


def _remanifest_prov(d, **changes):
    p = json.loads((d / "provenance.json").read_text(encoding="utf-8"))
    p.update(changes)
    (d / "provenance.json").write_text(json.dumps(p), encoding="utf-8")
    ns["write_artifact_manifest"](d)


record("P8a_byte_flip", error=tampered("flip", lambda d: (d / "metrics.json").write_text("{}", encoding="utf-8")))
record("P8b_extra_file", error=tampered("extra", lambda d: (d / "extra.txt").write_text("x", encoding="utf-8")))
record("P8c_other_revision", error=tampered("rev", lambda d: _remanifest_prov(d, baseModelRevision="f" * 40)))
record("P8d_branch_revision", error=tampered("main", lambda d: _remanifest_prov(d, baseModelRevision="main")))
record("P8e_trust_remote_code", error=tampered("trc", lambda d: _remanifest_prov(d, trustRemoteCode=True)))

# P9 clean default with the good bundle (directory mode) --------------------------------------
err, out = run(ns, 9, ARTIFACT_DIR=str(good_dir))
record("P9a_artifact_cell", error=err, out=out.strip()[-600:])
err, out = run(ns, 11)
record("P9b_attach", error=err, out=out.strip()[-400:])
err, out = run(ns, 13)
im = ns.get("input_manifest", {})
record("P9c_validate_prompts", error=err, n_inputs=len(im.get("inputs", [])), findings=im.get("findings"))
t = time.time()
err, out = run(ns, 15)
rows = ns.get("rows", [])
report = ns.get("report", {})
record("P9d_generate_export", error=err, gen_s=round(time.time() - t, 1),
       base_equals_adapted=[r["base"] == r["adapted"] for r in rows],
       sampled_differ=(len(set(ns.get("sampled", []))) == 2),
       report_task=report.get("task"), report_score_semantics=report.get("score_semantics"),
       report_sample_kind=report.get("sample_kind"), report_verdict=report.get("verdict"),
       outputs=sorted(os.listdir("outputs")), first_row=rows[0] if rows else None)
csv1 = Path("outputs/language_model_artifact_inference_generations.csv").read_text(encoding="utf-8")

# P10 active learning: CUSTOM_PROMPT then rerun sections 6-7 as documented ------------------
err13, _ = run(ns, 13, CUSTOM_PROMPT="Explain in one sentence what an adapter is.")
err15, _ = run(ns, 15)
res = json.loads(Path("outputs/language_model_artifact_inference_result.json").read_text(encoding="utf-8"))
record("P10_custom_prompt", error13=err13, error15=err15, n_generations=len(res["generations"]),
       custom_in_result=any(r["prompt"].startswith("Explain in one sentence") for r in res["generations"]),
       custom_row=res["generations"][-1])
err, _ = run(ns, 13, CUSTOM_PROMPT="x" * 20001)
record("P10b_custom_prompt_too_long", error=err)
err, _ = run(ns, 13, MAX_NEW_TOKENS=0)
record("P10c_max_new_tokens_zero", error=err)
run(ns, 13)  # restore

# P11 tiny adapter: run 'succeeds' while answers are identical ---------------------------------
err9, _ = run(ns, 9, ARTIFACT_DIR=str(tiny_dir))
err11, out11 = run(ns, 11)
err15, _ = run(ns, 15)
rows = ns.get("rows", [])
record("P11_tiny_adapter_run_succeeds", error9=err9, error11=err11, error15=err15,
       base_equals_adapted=[r["base"] == r["adapted"] for r in rows],
       note="LoRA B ~1e-9: non-zero check passes; Interpretation says a successful run proves the adapter changes answers")

# P12 re-attach in the same kernel (reuse journey: switch ARTIFACT_DIR, rerun 4-7) -------------
err9, _ = run(ns, 9, ARTIFACT_DIR=str(good_dir))
err11, out11 = run(ns, 11)
m = ns.get("model")
lora_layers = sum(1 for n, _ in m.named_modules() if n.endswith("lora_A")) if m is not None else None
nested = None
try:
    q = next(mod for n, mod in m.named_modules() if n.endswith("self_attn.q_proj"))
    nested = type(getattr(q, "base_layer", None)).__name__
except Exception as exc:  # noqa: BLE001
    nested = f"err {exc}"
err15, _ = run(ns, 15)
rows2 = ns.get("rows", [])
fresh = {}
# compare with a genuinely fresh attach of the good bundle on a fresh base
base_fresh = ns["pipe"].reload_base()
from peft import PeftModel  # noqa: E402
fm = PeftModel.from_pretrained(base_fresh, str(good_dir), is_trainable=False).eval()
fresh_answer = ns["pipe"].generate(ns["PROMPTS"][0], model=fm, max_new_tokens=ns["MAX_NEW_TOKENS"])
record("P12_reattach_same_kernel", error9=err9, error11=err11, error15=err15,
       q_proj_base_layer_type=nested, lora_A_modules=lora_layers,
       adapted_matches_fresh_attach=(rows2[0]["adapted"] == fresh_answer) if rows2 else None,
       reattached_adapted=rows2[0]["adapted"][:160] if rows2 else None, fresh_adapted=fresh_answer[:160])

# P13 zero adapter rejected ---------------------------------------------------------------
base_fresh2 = ns["pipe"].reload_base()
ns["pipe"].model = base_fresh2
err9, _ = run(ns, 9, ARTIFACT_DIR=str(zero_dir))
err11, _ = run(ns, 11)
record("P13_zero_adapter", error9=err9, error11=err11)

# P14 logit-level checks (text answers above are short echoes, so compare logits) -------------
def last_logits(model, prompt):
    text = ns["pipe"].render_chat([{"role": "user", "content": prompt}], add_generation_prompt=True)
    ids = ns["pipe"].tokenizer(text, return_tensors="pt", add_special_tokens=False)
    with torch.inference_mode():
        return model(**ids).logits[0, -1].float()


prompt0 = ns["PROMPTS"][0]
# (a) good bundle attached once to a fresh base: adapter on vs off
b1 = ns["pipe"].reload_base()
g1 = PeftModel.from_pretrained(b1, str(good_dir), is_trainable=False).eval()
on = last_logits(g1, prompt0)
with g1.disable_adapter():
    off = last_logits(g1, prompt0)
# (b) the notebook's reuse sequence: section 5 run with the tiny bundle, then rerun with the good bundle
b2 = ns["pipe"].reload_base()
ns["pipe"].model = b2
run(ns, 9, ARTIFACT_DIR=str(tiny_dir)); run(ns, 11)
run(ns, 9, ARTIFACT_DIR=str(good_dir)); e11, _ = run(ns, 11)
re_on = last_logits(ns["model"], prompt0)
with ns["model"].disable_adapter():
    re_off = last_logits(ns["model"], prompt0)
base_plain = last_logits(ns["pipe"].reload_base(), prompt0)
record("P14_logits", error11=e11,
       good_on_vs_off_maxabs=float((on - off).abs().max()),
       reattach_on_vs_fresh_on_maxabs=float((re_on - on).abs().max()),
       reattach_off_vs_plain_base_maxabs=float((re_off - base_plain).abs().max()),
       peft_config_keys=list(getattr(ns["model"], "peft_config", {}).keys()),
       note="(b) reruns sections 4-5 in one kernel: tiny bundle first, then good bundle")

RESULTS["wall_s"] = round(time.time() - T0, 1)
record("DONE", wall_s=RESULTS["wall_s"])
