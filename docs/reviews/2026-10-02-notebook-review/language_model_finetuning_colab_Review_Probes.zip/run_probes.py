"""Probes for the Notebook Review Framework v1 review of
tutorials/language_model_finetuning_colab.ipynb (language-model-pipeline @ 311b3c0).

CPU only. No GPU, no 4-bit kernels, no SmolLM2 weights are loaded. Every probe states its
evidence basis. Stand-in probes (P09) use a tiny randomly initialised Llama model built
locally; they demonstrate PEFT state behaviour the notebook relies on, not SmolLM2 results.

Usage:  python run_probes.py <repo_worktree> <kaggle_evidence_dir> <out_dir>
Env:    PYTHONPATH may add a --target dir holding peft==0.18.0, accelerate==1.11.0, pyarrow,
        nbformat (the reviewer did not install into any shared environment).
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import io
import json
import subprocess
import sys
import time
import traceback
import warnings
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
EVID = Path(sys.argv[2]).resolve()
OUT = Path(sys.argv[3]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
NB_PATH = REPO / "tutorials" / "language_model_finetuning_colab.ipynb"
RESULTS: dict[str, dict] = {}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def probe(pid: str, basis: str):
    def wrap(fn):
        started = time.time()
        try:
            out = fn()
            RESULTS[pid] = {"basis": basis, "status": "ok", **(out or {})}
        except Exception as exc:  # record, never hide
            RESULTS[pid] = {"basis": basis, "status": "error", "error": f"{type(exc).__name__}: {exc}",
                            "traceback": traceback.format_exc()[-2000:]}
        RESULTS[pid]["seconds"] = round(time.time() - started, 2)
        (OUT / "results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False), encoding="utf-8")
        return fn
    return wrap


NB = json.loads(NB_PATH.read_text(encoding="utf-8"))
CELLS = NB["cells"]
SRC = ["".join(c["source"]) if isinstance(c["source"], list) else c["source"] for c in CELLS]


def load_module():
    spec = importlib.util.spec_from_file_location("lm_pipeline_probe", REPO / "src" / "lmpipeline" / "pipeline.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["lm_pipeline_probe"] = mod  # dataclasses need the module registered
    spec.loader.exec_module(mod)
    return mod


@probe("P01_structure", "direct execution (static parse/compile, CPU)")
def p01():
    import nbformat
    nb = nbformat.reads(NB_PATH.read_text(encoding="utf-8"), as_version=4)
    try:
        nbformat.validate(nb)
        valid = True
        verr = None
    except Exception as exc:  # noqa: BLE001
        valid, verr = False, str(exc)[:300]
    code = [i for i, c in enumerate(CELLS) if c["cell_type"] == "code"]
    compiled = {}
    for i in code:
        try:
            compile(SRC[i], f"cell{i}", "exec")
            compiled[i] = "ok"
        except SyntaxError as exc:
            compiled[i] = f"SyntaxError {exc}"
    outputs = sum(len(CELLS[i].get("outputs", [])) for i in code)
    counts = [CELLS[i].get("execution_count") for i in code if CELLS[i].get("execution_count") is not None]
    return {"nbformat_valid": valid, "nbformat_error": verr, "cells": len(CELLS), "code_cells": code,
            "compile": compiled, "persisted_outputs": outputs, "execution_counts": counts,
            "metadata_dimer": NB["metadata"].get("dimer"),
            "placeholders": [i for i, s in enumerate(SRC) if any(t in s for t in ("TODO", "TBD", "FIXME", "WRITE ME"))]}


@probe("P02_generator_parity", "direct execution (repo generator --check, CPU)")
def p02():
    proc = subprocess.run([sys.executable, "tools/build_notebook.py", "--check"], cwd=REPO,
                          capture_output=True, text=True, timeout=300)
    module_sha = sha256(REPO / "src" / "lmpipeline" / "pipeline.py")
    return {"exit_code": proc.returncode, "stdout_tail": proc.stdout[-600:], "stderr_tail": proc.stderr[-600:],
            "src_module_sha256": module_sha,
            "notebook_declared_module_sha256": NB["metadata"]["dimer"]["generated_from"]["module_sha256"],
            "match": module_sha == NB["metadata"]["dimer"]["generated_from"]["module_sha256"]}


@probe("P03_rerun_state_static", "source inspection (AST)")
def p03():
    def names(src, ctx):
        tree = ast.parse(src)
        return sorted({n.id for n in ast.walk(tree) if isinstance(n, ast.Name) and isinstance(n.ctx, ctx)})
    deleted_21 = names(SRC[21], ast.Del)
    loads_19 = names(SRC[19], ast.Load)
    loads_13 = names(SRC[13], ast.Load)
    return {
        "cell21_deletes": deleted_21,
        "cell19_reads_deleted_names": sorted(set(deleted_21) & set(loads_19)),
        "cell21_reassigns_pipe_model": "pipe.model = pipe.reload_base()" in SRC[21],
        "load_adapter_wraps_self_model": "base = self.model if base_model is None else base_model" in SRC[5],
        "cell13_baseline_uses_pipe_model_default": "pipe.generate(prompt)" in SRC[13] and "model=" not in SRC[13].split("BASELINE_OUTPUTS")[1].split("\n")[0],
        "cell15_wraps_pipe_model_in_place": "get_peft_model(prepare_model_for_kbit_training(pipe.model)" in SRC[15],
        "howto_rerun_instruction": [line for line in SRC[1].splitlines() if "re-run from that cell down" in line],
        "cell19_has_form_fields": [line.strip() for line in SRC[19].splitlines() if "@param" in line],
    }


@probe("P04_terminal_colab_import", "source inspection (AST)")
def p04():
    tree = ast.parse(SRC[21])
    top = []
    for node in tree.body:
        if isinstance(node, ast.ImportFrom) and node.module == "google.colab":
            top.append(node.lineno)
    guarded_9 = "if USE_BYOD:\n    from google.colab import files" in SRC[9]
    return {"cell21_unguarded_google_colab_import_lines": top,
            "cell21_last_line": SRC[21].strip().splitlines()[-1],
            "cell9_colab_import_guarded_by_USE_BYOD": guarded_9,
            "prereq_mentions_other_cuda_machine": "or another CUDA machine" in SRC[1]}


@probe("P05_base_loss_baseline", "source inspection")
def p05():
    calls = [(i, line.strip()) for i, s in enumerate(SRC) for line in s.splitlines()
             if "evaluate_loss(" in line and CELLS[i]["cell_type"] == "code" and i != 5]
    return {"evaluate_loss_calls_outside_module": calls,
            "header_promises_base_vs_adapted_loss": "evaluates loss/perplexity base vs adapted" in SRC[0],
            "evaluation_report_baselines_literal_empty": '"baselines": [],' in SRC[5]}


@probe("P06_kaggle_evidence", "documented execution evidence (Kaggle T4, e9d7e6b / blob 469911578d05)")
def p06():
    summary = json.loads((EVID / "run_summary.json").read_text(encoding="utf-8"))
    ex = json.loads((EVID / "executed.ipynb").read_text(encoding="utf-8"))
    p1 = json.loads((EVID / "executed-pass1.ipynb").read_text(encoding="utf-8"))

    def text(nb, idx):
        out = []
        for o in nb["cells"][idx].get("outputs", []):
            if o.get("output_type") == "stream":
                out.append("".join(o["text"]) if isinstance(o["text"], list) else o["text"])
            elif o.get("output_type") == "error":
                out.append(f"{o['ename']}: {o['evalue']}")
        return "".join(out)
    c15 = text(ex, 15)
    c21 = text(ex, 21)
    c9 = text(ex, 9)
    c13 = text(ex, 13)
    pass1_err = text(p1, 3).splitlines()[-1]
    result = json.loads((EVID / "outputs" / "language_model_finetuning_result.json").read_text(encoding="utf-8"))
    return {
        "identity": summary["identity"],
        "passes": [{k: v for k, v in p.items() if k != "error"} for p in summary["runner"]["passes"]],
        "restarted_after_install_cell": summary["runner"].get("restarted_after_install_cell"),
        "pass1_cell3_error": pass1_err,
        "cell9_gpu_line": [ln for ln in c9.splitlines() if "'gpu'" in ln],
        "cell9_splits_line": [ln for ln in c9.splitlines() if "'splits'" in ln],
        "cell13_baseline": c13.split("\n", 1)[1][-700:] if "\n" in c13 else c13,
        "cell15_trainable_line": [ln for ln in c15.splitlines() if "trainable_percent" in ln],
        "cell15_epoch_line": [ln for ln in c15.splitlines() if ln.startswith("epoch")],
        "cell21_reload_line": [ln for ln in c21.splitlines() if "in_memory_adapted_opening" in ln],
        "reload_record": result.get("reload"),
        "metrics": result.get("metrics"),
        "evidence_sha256": {p.name: sha256(p) for p in (EVID / "run_summary.json", EVID / "executed.ipynb", EVID / "executed-pass1.ipynb")},
    }


@probe("P07_sample_path_cpu", "direct execution (CPU; real pinned tokenizer + pinned sample parquet; no model weights)")
def p07():
    from huggingface_hub import hf_hub_download
    import pandas as pd
    from transformers import AutoTokenizer
    m = load_module()
    tok_dir = OUT / "_tok"
    manifest = json.loads((REPO / "weights" / "smollm2-360m" / "dimer-base-manifest.json").read_text(encoding="utf-8"))
    want = {f["path"]: f for f in manifest["files"]}
    digests = {}
    for name in ("tokenizer.json", "tokenizer_config.json", "special_tokens_map.json", "vocab.json", "merges.txt"):
        p = Path(hf_hub_download(m.MODEL_ID, name, revision=m.MODEL_REVISION, local_dir=str(tok_dir)))
        digests[name] = sha256(p) == want[name]["sha256"]
    tok = AutoTokenizer.from_pretrained(str(tok_dir), local_files_only=True)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    pipe = m.LanguageModelPipeline(tok, None)
    sample = m.SAMPLE_DATASETS["Sample: Filipino SFT"]
    pq = Path(hf_hub_download(sample["dataset_id"], "data/train/part-00000.parquet", repo_type="dataset",
                              revision=sample["revision"], local_dir=str(OUT / "_data")))
    frame = pd.read_parquet(pq)
    raw = frame.to_dict(orient="records")
    all_rows = sorted((m.canonical(dict(r)) for r in raw), key=m.fingerprint)
    rows, skipped = [], 0
    for row in all_rows:
        if len(rows) == 120:
            break
        if pipe.token_length(row) <= 512:
            rows.append(row)
        else:
            skipped += 1
    splits = m.manufacture_validation(rows)
    digest = m.dataset_digest(splits)
    manifest_in = m.validate_inputs(splits, 512, token_length=pipe.token_length)
    probe_split = {"train": splits["train"], "validation": [*splits["validation"], splits["train"][0]]}
    try:
        m.validate_inputs(probe_split, 512)
        leak = "accepted (unexpected)"
    except ValueError as exc:
        leak = str(exc)
    masked = pipe.prepare_splits(splits, 512)
    sup = {k: sum(m.supervised_token_count(lbl) for _, lbl in v) for k, v in masked.items()}
    shown = m.show_supervision(tok, *masked["train"][0])
    # Near-duplicate signal: shared first user line (template-style prompts) across train/validation.
    first = lambda r: r["messages"][0]["content"].split("\n")[0] if r["messages"][0]["role"] == "user" else r["messages"][1]["content"].split("\n")[0]  # noqa: E731
    shared_openers = sorted({first(r) for r in splits["train"]} & {first(r) for r in splits["validation"]})
    return {"tokenizer_files_match_manifest": digests, "raw_rows": len(raw), "columns": list(frame.columns),
            "splits": {k: len(v) for k, v in splits.items()}, "skipped_long": skipped,
            "dataset_digest_prefix": digest[:16], "kaggle_digest_prefix": "b744d708c47877e0",
            "digest_matches_kaggle": digest[:16] == "b744d708c47877e0",
            "input_tokens": {i["split"]: i["tokens"] for i in manifest_in["inputs"]},
            "leak_probe_message": leak, "supervised_tokens": sup,
            "supervision_starts_after_generation_prompt": shown.count("⟦") == 1 and shown.rstrip().endswith("⟧"),
            "has_default_system_prompt": "You are a helpful AI assistant named SmolLM" in shown,
            "train_validation_shared_first_user_lines": len(shared_openers),
            "shared_opener_examples": shared_openers[:5]}


@probe("P08_byod_errors", "direct execution (CPU; notebook BYOD reader logic on synthetic files)")
def p08():
    m = load_module()

    def read_jsonl(path: Path):  # verbatim logic of cell 9
        return [m.canonical(json.loads(line)) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    root = OUT / "_byod"
    root.mkdir(exist_ok=True)
    cases = {
        "malformed_json_line_5": ['{"prompt": "a", "completion": "b"}'] * 4 + ['{"prompt": "a", completion: "b"}'],
        "unknown_schema_row_3": ['{"prompt": "a", "completion": "b"}'] * 2 + ['{"question": "a", "answer": "b"}'],
        "empty_assistant_row_2": ['{"prompt": "a", "completion": "b"}', '{"prompt": "a", "completion": "  "}'],
    }
    out = {}
    for name, lines in cases.items():
        p = root / f"{name}.jsonl"
        p.write_text("\n".join(lines), encoding="utf-8")
        try:
            read_jsonl(p)
            out[name] = "accepted"
        except Exception as exc:  # noqa: BLE001
            out[name] = f"{type(exc).__name__}: {exc}"
    # Over-length BYOD row: sample path sets such rows aside; BYOD path rejects the whole dataset.
    splits = {"train": [m.canonical({"prompt": f"q{i}", "completion": "x " * (600 if i == 0 else 3)}) for i in range(6)]}
    splits = {**splits, **m.manufacture_validation(splits["train"])} if "validation" not in splits else splits
    try:
        m.validate_inputs(splits, 512, token_length=lambda r: len(r["messages"][1]["content"].split()))
        out["over_length_row"] = "accepted"
    except Exception as exc:  # noqa: BLE001
        out["over_length_row"] = f"{type(exc).__name__}: {exc}"
    # BYOD manufactured validation = first fifth in file order (no shuffle).
    ordered = [m.canonical({"prompt": f"topic-A {i}" if i < 10 else f"topic-B {i}", "completion": "ok"}) for i in range(10 * 2)]
    held = m.manufacture_validation(ordered)["validation"]
    out["byod_validation_is_file_head"] = [r["messages"][0]["content"] for r in held]
    out["cell9_byod_has_location_field"] = any("BYOD_" in ln and "@param" in ln and "PATH" in ln.upper() for ln in SRC[9].splitlines())
    return out


@probe("P09_peft_state_standin", "direct execution (CPU stand-in: tiny random Llama, bf16, peft 0.18.0; NOT SmolLM2, NOT 4-bit)")
def p09():
    import torch
    from peft import LoraConfig, PeftModel, get_peft_model, prepare_model_for_kbit_training
    from transformers import LlamaConfig, LlamaForCausalLM
    torch.manual_seed(0)
    cfg = LlamaConfig(vocab_size=128, hidden_size=64, intermediate_size=128, num_hidden_layers=2,
                      num_attention_heads=4, num_key_value_heads=4, max_position_embeddings=64, tie_word_embeddings=True)
    snap = OUT / "_standin_snapshot"
    LlamaForCausalLM(cfg).to(torch.bfloat16).save_pretrained(snap, safe_serialization=True)

    def load_base():  # reload_base analogue: same files, same dtype
        return LlamaForCausalLM.from_pretrained(snap, dtype=torch.bfloat16).eval()
    x = torch.randint(0, 128, (1, 12))
    targets = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
    pipe_model = load_base()
    with torch.inference_mode():
        baseline = pipe_model(x).logits.float()
    dtypes_before = sorted({str(p.dtype) for p in pipe_model.parameters()})
    model = get_peft_model(prepare_model_for_kbit_training(pipe_model), LoraConfig(r=8, lora_alpha=16, target_modules=targets, task_type="CAUSAL_LM"))
    dtypes_after_prepare = sorted({str(p.dtype) for n, p in model.named_parameters() if "lora_" not in n})
    torch.manual_seed(1)
    with torch.no_grad():  # stand-in for training: make the adapter non-trivial
        for n, p in model.named_parameters():
            if "lora_B" in n:
                p.normal_(0, 0.5)
    model.eval()
    with torch.inference_mode():
        in_memory = model(x).logits.float()
    bundle = OUT / "_standin_bundle"
    model.save_pretrained(bundle, safe_serialization=True)
    # Cell 21: del model; pipe.model = reload_base(); reloaded = load_adapter -> PeftModel.from_pretrained(pipe.model)
    del model
    pipe_model = load_base()
    reloaded = PeftModel.from_pretrained(pipe_model, str(bundle), is_trainable=False).eval()
    with torch.inference_mode():
        reloaded_logits = reloaded(x).logits.float()
        # Rerun of cell 13 ("re-run from that cell down"): pipe.generate(prompt) uses pipe.model
        rerun_baseline = pipe_model(x).logits.float()
        with reloaded.disable_adapter():
            adapter_off = reloaded(x).logits.float()
    injected = any("lora_" in n for n, _ in pipe_model.named_parameters())
    # Rerun of cell 15 with LORA_RANK=16 on the already-injected pipe.model
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        model2 = get_peft_model(prepare_model_for_kbit_training(pipe_model), LoraConfig(r=16, lora_alpha=32, target_modules=targets, task_type="CAUSAL_LM"))
    ranks = sorted({tuple(p.shape) for n, p in model2.named_parameters() if "lora_A" in n})
    nested = sum(1 for n, _ in model2.named_modules() if n.count("base_layer") > 1)
    return {
        "dtypes_base": dtypes_before, "dtypes_after_prepare_model_for_kbit_training": dtypes_after_prepare,
        "max_abs_logit_diff_in_memory_vs_reloaded": float((in_memory - reloaded_logits).abs().max()),
        "argmax_agreement_in_memory_vs_reloaded": float((in_memory.argmax(-1) == reloaded_logits.argmax(-1)).float().mean()),
        "pipe_model_carries_lora_after_reload": injected,
        "max_abs_logit_diff_rerun_baseline_vs_true_baseline": float((rerun_baseline - baseline).abs().max()),
        "rerun_baseline_equals_adapter_on_output": bool(torch.allclose(rerun_baseline, reloaded_logits)),
        "adapter_off_equals_true_baseline": bool(torch.allclose(adapter_off, baseline, atol=1e-3)),
        "second_get_peft_model_warnings": [str(w.message)[:160] for w in caught if "PEFT" in str(w.message)],
        "lora_A_shapes_after_rank16_rerun": [list(s) for s in ranks],
        "nested_base_layer_modules": nested,
    }


def main():
    manifest = {}
    for rel in ["tutorials/language_model_finetuning_colab.ipynb", "src/lmpipeline/pipeline.py",
                "tools/build_notebook.py", "tools/notebook_template.py", "tutorials/README.md",
                "docs/release-verification.md", "tutorials/RELEASE_VERIFICATION.md", "README.md",
                "weights/smollm2-360m/dimer-base-manifest.json", "pyproject.toml"]:
        p = REPO / rel
        manifest[rel] = sha256(p) if p.exists() else None
    for p in sorted(EVID.glob("*.json")) + sorted(EVID.glob("*.ipynb")):
        manifest[f"kaggle-evidence/{p.name}"] = sha256(p)
    (OUT / "source_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "traceback"} for k, v in RESULTS.items()}, indent=1, ensure_ascii=False)[:20000])


main()
